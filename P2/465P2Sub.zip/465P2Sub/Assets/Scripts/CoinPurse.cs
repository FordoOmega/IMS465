using UnityEngine;

public interface CoinPurse
{
    bool TrySpend(int amount);
    void Refund(int amount);
    void AddCoin(int amount);
}