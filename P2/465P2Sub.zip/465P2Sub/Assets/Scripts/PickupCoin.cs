using UnityEngine;

public class PickupCoin : MonoBehaviour
{
    [SerializeField] private int value = 1;
    // private UIManager UI;

    void Start()
    {
        // UI = GameObject.Find("Canvas").GetComponent<UIManager>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent(out CoinPurse purse))
        {
            purse.AddCoin(value);
            // UI.UpdateCoinsAdd(value);
            Destroy(gameObject);
        }
    }
}