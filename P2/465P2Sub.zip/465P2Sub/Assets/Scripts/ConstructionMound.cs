using UnityEngine;

public class ConstructionMound : MonoBehaviour, IInteractable
{
    [SerializeField] private CoinSlot[] slots;   // drag the child slots in here
    [SerializeField] private float secondsPerCoin = 0.4f;
    // private UIManager UI;

    private CoinPurse Ipurse;
    private float timer;
    private int filled;
    private bool paid;

    void Start()
    {
        // UI = GameObject.Find("Canvas").GetComponent<UIManager>();
    }

    public void OnInteractEnter()
    {
        foreach (var s in slots) s.ShowGhost(true);
    }

    public void OnInteractHold(float deltaTime, CoinPurse purse)
    {
        if (filled >= slots.Length) return;

        // Pay the full cost once, all or nothing.
        if (!paid)
        {
            if (!purse.TrySpend(slots.Length)) return;
            paid = true;
            Ipurse = purse;
            
        }

        timer += deltaTime;
        if (timer >= secondsPerCoin)
        {
            timer -= secondsPerCoin;
            // UI.UpdateCoinsSub(1);
            slots[filled++].Fill();
        }
    }

    public void OnInteractRelease()
    {
        CancelBuild();
        foreach (var s in slots) s.ShowGhost(true);
    }

    public void OnInteractExit()
    {
        CancelBuild();
        foreach (var s in slots) s.ShowGhost(false);
    }

    private void CancelBuild()
    {
        timer = 0f;
        if (!paid || filled >= slots.Length) return;

        foreach (var s in slots) s.Empty();
        Ipurse.Refund(slots.Length);
        // UI.UpdateCoinsAdd(slots.Length);
        filled = 0;
        paid = false;
    }
}