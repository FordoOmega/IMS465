using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI coinDisplay;
    [SerializeField] private Player player;

    private void Start()
    {
        player.CoinsChanged += ShowCoins;
        ShowCoins(player.Coins);
    }

    private void OnDestroy()
    {
        if (player != null) player.CoinsChanged -= ShowCoins;
    }

    private void ShowCoins(int total) => coinDisplay.text = "Coins: " + total;
}
