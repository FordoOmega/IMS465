using UnityEngine;

public interface IInteractable
{
    void OnInteractEnter();
    void OnInteractHold(float deltaTime, CoinPurse purse);
    void OnInteractRelease();
    void OnInteractExit();
}