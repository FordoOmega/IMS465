using UnityEngine;

public interface IInteractable
{
    void OnInteractEnter();
    void OnInteractHold(float deltaTime);
    void OnInteractExit();
}