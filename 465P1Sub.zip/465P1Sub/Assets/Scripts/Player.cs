using UnityEngine;
using UnityEngine.Windows;
using static UnityEngine.GraphicsBuffer;

public class Player : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float rayDistance = 1.5f;
    [SerializeField] private LayerMask interactMask = ~0;

    private Rigidbody2D rb;
    private PlayerInputActions input;

    private float moveX;
    private IInteractable target;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        transform.position = new Vector3(0, -2.38f, 0);
        rb = GetComponent<Rigidbody2D>();
        input = new PlayerInputActions();
    }

    private void OnEnable() => input.Player.Enable();

    private void OnDisable()
    {
        input.Player.Disable();
        SetTarget(null);
    }

    // Update is called once per frame
    void Update()
    {
        moveX = input.Player.Move.ReadValue<Vector2>().x;

        SetTarget(FindInteractable());

        if (target != null && input.Player.Interact.IsPressed())
            target.OnInteractHold(Time.deltaTime);

        Boundary();
    }

    private void Boundary()
    {
        if (transform.position.x < -9.5f)
        {
            transform.position = new Vector3(9.5f, transform.position.y, 0);
        } else if (transform.position.x > 9.5f) 
        {
            transform.position = new Vector3(-9.5f, transform.position.y, 0);
        }
    }

    private void FixedUpdate()
    {
        Vector2 step = Vector2.right * (moveX * moveSpeed * Time.fixedDeltaTime);
        rb.MovePosition(rb.position + step);
    }

    private IInteractable FindInteractable()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, rayDistance, interactMask);
        if (hit.collider != null && hit.collider.TryGetComponent(out IInteractable interactable))
            return interactable;
        return null;
    }

    private void SetTarget(IInteractable newTarget)
    {
        if (ReferenceEquals(newTarget, target)) return;
        target?.OnInteractExit();
        target = newTarget;
        target?.OnInteractEnter();
    }
}
