using UnityEngine;

public class CoinSlot : MonoBehaviour
{
    [SerializeField] private SpriteRenderer ghost;
    [SerializeField] private SpriteRenderer coin;

    private void Awake()
    {
        ghost.enabled = false;
        coin.enabled = false;
    }

    public void ShowGhost(bool show)
    {
        if (!coin.enabled) ghost.enabled = show;
    }

    public void Fill()
    {
        ghost.enabled = false;
        coin.enabled = true;
    }
}
