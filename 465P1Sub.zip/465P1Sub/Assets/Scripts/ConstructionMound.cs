using UnityEngine;

public class ConstructionMound : MonoBehaviour, IInteractable
{
    [SerializeField] private CoinSlot[] slots;   // drag the child slots in here
    [SerializeField] private float secondsPerCoin = 0.4f;

    private float timer;
    private int filled;

    public void OnInteractEnter()
    {
        foreach (var s in slots) s.ShowGhost(true);
    }

    public void OnInteractExit()
    {
        foreach (var s in slots) s.ShowGhost(false);
        timer = 0f;
    }

    public void OnInteractHold(float deltaTime)
    {
        if (filled >= slots.Length) return;
        timer += deltaTime;
        if (timer >= secondsPerCoin)
        {
            timer -= secondsPerCoin;
            slots[filled++].Fill();
        }
    }
}