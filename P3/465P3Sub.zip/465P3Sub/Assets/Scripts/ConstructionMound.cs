using UnityEngine;

public class ConstructionMound : MonoBehaviour, IInteractable
{
    [SerializeField] private CoinSlot[] slots;          // tier 0 cost
    [SerializeField] private CoinSlot[] upgradeSlots;   // tier 1 cost
    [SerializeField] private float secondsPerCoin = 0.4f;
    [SerializeField] private GameObject scaffold;
    [SerializeField] private GameObject building;
    [SerializeField] private float buildSeconds = 5f;

    private CoinPurse Ipurse;
    private float timer;
    private int filled;
    private bool paid;
    private float buildTimer;
    private bool constructing;
    private int tier = 0;

    // The slot set for the current tier, or null when there is nothing left to build.
    private CoinSlot[] CurrentSlots => tier == 0 ? slots : tier == 1 ? upgradeSlots : null;

    private void Awake()
    {
        scaffold.SetActive(false);
        building.SetActive(false);
    }

    private void Update()
    {
        if (!constructing) return;

        buildTimer += Time.deltaTime;
        if (buildTimer >= buildSeconds)
            FinishConstruction();
    }

    public void OnInteractEnter()
    {
        var current = CurrentSlots;
        if (constructing || current == null) return;

        foreach (var s in current) s.ShowGhost(true);
    }

    public void OnInteractHold(float deltaTime, CoinPurse purse)
    {
        var current = CurrentSlots;
        if (constructing || current == null) return;
        if (filled >= current.Length) return;

        // Pay the full cost once, all or nothing.
        if (!paid)
        {
            if (!purse.TrySpend(current.Length)) return;
            paid = true;
            Ipurse = purse;
        }

        timer += deltaTime;
        if (timer >= secondsPerCoin)
        {
            timer -= secondsPerCoin;
            current[filled++].Fill();

            if (filled >= current.Length)
                Scaffolding();
        }
    }

    public void OnInteractRelease()
    {
        var current = CurrentSlots;
        if (constructing || current == null) return;

        CancelBuild();
        foreach (var s in current) s.ShowGhost(true);
    }

    public void OnInteractExit()
    {
        var current = CurrentSlots;
        if (constructing || current == null) return;

        CancelBuild();
        foreach (var s in current) s.ShowGhost(false);
    }

    private void CancelBuild()
    {
        timer = 0f;

        var current = CurrentSlots;
        if (current == null || !paid || filled >= current.Length) return;

        foreach (var s in current) s.Empty();
        Ipurse.Refund(current.Length);
        filled = 0;
        paid = false;
    }

    private void Scaffolding()
    {
        // Uses CurrentSlots, so it must run before tier is incremented.
        foreach (var s in CurrentSlots) s.gameObject.SetActive(false);

        // Reset per-tier state so the next tier starts clean.
        filled = 0;
        paid = false;
        timer = 0f;

        if (tier > 0)
        {
            building.SetActive(false);
        }
        scaffold.SetActive(true);
      
        buildTimer = 0f;
        constructing = true;
    }

    private void FinishConstruction()
    {
        constructing = false;
        scaffold.SetActive(false);
        building.SetActive(true);
        tier++;
    }
}